package backend.mipsCode.instruction;

import backend.mipsCode.MipsCode;

public interface Instruction extends MipsCode {
}
