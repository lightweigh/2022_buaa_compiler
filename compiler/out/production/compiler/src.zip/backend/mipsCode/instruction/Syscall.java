package backend.mipsCode.instruction;

public class Syscall implements Instruction {
    @Override
    public String toString() {
        return "syscall\n\n";
    }
}
