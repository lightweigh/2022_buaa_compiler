package frontend.grammar;

import java.io.BufferedWriter;
import java.io.IOException;

public class Component {

    public void print(BufferedWriter output) throws IOException {
    }
}
