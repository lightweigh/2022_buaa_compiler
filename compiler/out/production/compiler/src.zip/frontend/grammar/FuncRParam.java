package frontend.grammar;

public class FuncRParam {
}
