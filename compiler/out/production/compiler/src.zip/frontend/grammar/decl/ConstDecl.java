package frontend.grammar.decl;

import com.sun.org.apache.bcel.internal.Const;
import frontend.Lexer;
import frontend.grammar.def.ConstDef;
import frontend.token.Token;

import java.io.BufferedWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class ConstDecl extends Decl {
    //  ConstDecl → 'const' BType ConstDef { ',' ConstDef } ';'
    private Token constTK;
    private Token intTK;
    private ArrayList<Token> seperators;
    private ArrayList<ConstDef> constDefs;
    private Token semicon;

    public ConstDecl(Token constTK, Token intTK, ArrayList<Token> seperators,
                     ArrayList<ConstDef> constDefs, Token semicon) {
        this.constTK = constTK;
        this.intTK = intTK;
        this.seperators = seperators;
        this.constDefs = constDefs;
        this.semicon = semicon;
    }

    public void print(BufferedWriter output) throws IOException {
        output.write(constTK.toString());
        output.write(intTK.toString());
        Iterator<Token> iterSeperators = seperators.iterator();
        for (int i = 0; i < constDefs.size(); i++) {
            constDefs.get(0).print(output);
            if (iterSeperators.hasNext()) {
                Token comma = iterSeperators.next();
                output.write(comma.toString());
            }
        }
        output.write(semicon.toString());
        output.write("<ConstDecl>\n");
    }
}
