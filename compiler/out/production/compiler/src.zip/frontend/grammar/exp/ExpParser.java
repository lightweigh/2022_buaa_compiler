package frontend.grammar.exp;

import com.sun.deploy.security.ValidationState;
import frontend.Lexer;
import frontend.token.Token;

public class ExpParser {

    /*public Exp expParser() {
        Token.Type type = Lexer.tokenList.peek(0).getRefType();
        if (type == Token.Type.IDENFR || type == Token.Type.LPARENT ||
                type == )
    }*/
}
