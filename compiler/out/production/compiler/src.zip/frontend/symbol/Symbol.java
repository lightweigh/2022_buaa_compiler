package frontend.symbol;

public class Symbol {
    private String symName;

    public Symbol(String symName) {
        this.symName = symName;
    }

    public String getSymName() {
        return symName;
    }
}
