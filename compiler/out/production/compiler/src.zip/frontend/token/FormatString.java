package frontend.token;

public class FormatString extends Token{
    public FormatString(Type refType, int line, String content) {
        super(refType, line, content);
    }
}
