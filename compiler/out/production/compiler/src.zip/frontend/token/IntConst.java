package frontend.token;

public class IntConst extends Token {
    public IntConst(Type refType, int line, String content) {
        super(refType, line, content);
    }
}
