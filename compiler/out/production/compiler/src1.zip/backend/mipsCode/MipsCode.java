package backend.mipsCode;

public interface MipsCode {
}
