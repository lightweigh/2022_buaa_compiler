package backend.mipsCode.global;

import backend.mipsCode.MipsCode;

public class Data implements MipsCode {

    @Override
    public String toString() {
        return ".data\n";
    }
}
