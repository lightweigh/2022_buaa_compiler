package frontend.grammar.exp.condExp;

import java.io.BufferedWriter;
import java.io.IOException;

public interface CondExp {

    public void print(BufferedWriter output) throws IOException;
}
