package frontend;

import frontend.token.Token;

import java.util.LinkedList;
import java.util.List;

public class SymTable {
    private List<Token> tokens = new LinkedList<>();
}
