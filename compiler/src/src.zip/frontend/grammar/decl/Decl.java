package frontend.grammar.decl;

import frontend.grammar.Component;

import java.io.BufferedWriter;
import java.io.IOException;

public class Decl extends Component {

    public void print(BufferedWriter output) throws IOException {
        System.out.println("Decl print. Wrong!");
    }
}
