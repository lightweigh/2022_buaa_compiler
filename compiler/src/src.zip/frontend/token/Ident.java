package frontend.token;

public class Ident extends Token{
    public Ident(Type refType, int line, String content) {
        super(refType, line, content);
    }
}
