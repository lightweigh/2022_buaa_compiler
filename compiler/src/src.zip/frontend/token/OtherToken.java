package frontend.token;

public class OtherToken extends Token {
    public OtherToken(Type refType, int line, String content) {
        super(refType, line, content);
    }
}
